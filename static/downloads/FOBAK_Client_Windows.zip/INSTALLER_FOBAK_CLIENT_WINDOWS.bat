@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
title Installation FOBAK Client Windows

set "ONLINE_URL=https://votre-domaine-fobak.org"
set "LOCAL_URL=http://192.168.1.10:5000"

echo =====================================================
echo       FOBAK MANAGER PRO - CLIENT WINDOWS
echo =====================================================
echo.
set /p "ONLINE_INPUT=Adresse en ligne [%ONLINE_URL%] : "
if defined ONLINE_INPUT set "ONLINE_URL=%ONLINE_INPUT%"
set /p "LOCAL_INPUT=Adresse locale [%LOCAL_URL%] : "
if defined LOCAL_INPUT set "LOCAL_URL=%LOCAL_INPUT%"

set "APPDIR=%LOCALAPPDATA%\FOBAK Client"
if not exist "%APPDIR%" mkdir "%APPDIR%"
>"%APPDIR%\FOBAK_Client.cmd" echo @echo off
>>"%APPDIR%\FOBAK_Client.cmd" echo setlocal
>>"%APPDIR%\FOBAK_Client.cmd" echo set "LOCAL_URL=%LOCAL_URL%"
>>"%APPDIR%\FOBAK_Client.cmd" echo set "ONLINE_URL=%ONLINE_URL%"
>>"%APPDIR%\FOBAK_Client.cmd" echo powershell -NoProfile -ExecutionPolicy Bypass -Command "$u=$env:LOCAL_URL; try { $r=Invoke-WebRequest -UseBasicParsing -Uri $u -TimeoutSec 3; if($r.StatusCode -ge 200){Start-Process $u; exit} } catch{}; Start-Process $env:ONLINE_URL"
>>"%APPDIR%\FOBAK_Client.cmd" echo endlocal

set "DESKTOP=%USERPROFILE%\Desktop"
for /f "usebackq delims=" %%D in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('Desktop')"`) do set "DESKTOP=%%D"
set "SHORTCUT=%DESKTOP%\FOBAK Manager Pro.lnk"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%SHORTCUT%');$s.TargetPath='%APPDIR%\FOBAK_Client.cmd';$s.WorkingDirectory='%APPDIR%';$s.Description='FOBAK Manager Pro - local ou en ligne';$s.Save()"

echo.
echo Installation terminee.
echo Le raccourci FOBAK Manager Pro a ete cree sur le Bureau.
echo Il ouvre le serveur local s'il repond, sinon la version en ligne.
echo.
pause
endlocal
